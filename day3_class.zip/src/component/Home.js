import React,{Component,Fragment} from "react"
import ProductCards from "./ProductCards"
import SearchAppBar from "./SearchAppBar"
let product=()=>{
    return [
        {
        name:"lion",
        price:1000
    },
    {
        name:"lion",
        price:1000
    },
    {
        name:"lion",
        price:1000
    },
    {
        name:"lion",
        price:1000
    }, {
        name:"lion",
        price:1000
    },
]
}

export default class Home extends Component{
    constructor()
    {
        super()
        this.state={
            p:[]
        }
    }

    componentDidMount(props){
        let pro=product()
        this.setState({p:pro})
    }
    render(){
        return <Fragment>
            <SearchAppBar />
            <ProductCards product={this.state.p} />
            </Fragment>
    }
}