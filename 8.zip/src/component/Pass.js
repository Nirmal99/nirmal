import React,{Component,Fragment} from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import InputBase from '@material-ui/core/InputBase';
import { fade, makeStyles,withStyles } from '@material-ui/core/styles';
import MenuIcon from '@material-ui/icons/Menu';
import SearchIcon from '@material-ui/icons/Search';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Menu from '@material-ui/core/Menu';
import Divider from '@material-ui/core/Divider';
import ProductCards from "./ProductCards"
import Home from "./Home"



const useStyles = makeStyles(theme => ({
  formControl: {
    // margin: theme.spacing(1),
    width: 125,
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15)
  },
root: {
flexGrow: 1,
},
menuButton: {
marginRight: theme.spacing(2),
},
title: {
flexGrow: 1,
display: 'none',
[theme.breakpoints.up('sm')]: {
  display: 'block',
},
},
search: {
position: 'relative',
borderRadius: theme.shape.borderRadius,
backgroundColor: fade(theme.palette.common.white, 0.15),
'&:hover': {
  backgroundColor: fade(theme.palette.common.white, 0.25),
},
marginLeft: 0,
width: '100%',
[theme.breakpoints.up('sm')]: {
  marginLeft: theme.spacing(1),
  width: 'auto',
},
},
searchIcon: {
width: theme.spacing(7),
height: '100%',
position: 'absolute',
pointerEvents: 'none',
display: 'flex',
alignItems: 'center',
justifyContent: 'center',
},
inputRoot: {
color: 'inherit',
},
inputInput: {
padding: theme.spacing(1, 1, 1, 7),
transition: theme.transitions.create('width'),
width: '100%',
[theme.breakpoints.up('sm')]: {
  width: 120,
  '&:focus': {
    width: 200,
  },
},
},
selectEmpty: {
  marginTop: theme.spacing(2),
},
  
}));


export default withStyles(useStyles)(class SearchAppBar extends React.Component{
 state={
auth:true,
anchorEl:null,
search:null,
category:null,
submitButton:false,
data:[],
final:[]
}
  products=()=>{
    return [
        {
        name:"lion",
        price:1000
    },
    {
        name:"lion",
        price:1000
    },
    {
        name:"lion",
        price:1000
    },
    {
        name:"lion",
        price:1000
    }, {
        Name:"lion",
        price:1000
    },
]
}
  
  handleChangeSearch = event => {
    // setSearch(event.target.value)
    console.log(event.target.value)
    this.setState({search:event.target.value})
  };
  handleChangeCategory = event => {
    // setCategory(event.target.value)
    console.log(event.target.value)
    this.setState({category:event.target.value})

  };
  handleSubmit=event=>{
    // console.log("nirmal")
    // console.log(category)
    // console.log(search)
    console.log(this.state)
    let final= this.products().filter(data=>data[this.state.category]===this.state.search)
    // console.log(final)
    this.setState({final:final})
    this.setState({final:final,submitButton:true})

    console.log(this.state)
    event.preventDefault()
    // setfinalData(final)
    // console.log(data)
  
    // setsubmitButton(true)    
    // <ProductCards product={final} />
    // <ProductCards product={final} />

  }
  
  handleMenu = event => {
    // setAnchorEl(event.currentTarget);
  };

  handleClose = () => {
    // setAnchorEl(null);
  };
  render(){
    const {classes}=this.props
    console.log(this.state)
   if(this.state.submitButton==true){
   return <Home search={this.state.search} category={this.state.category} />
     
   }
   else{
  return (
    <div className={classes.root}>
      {console.log(this.state.search)}
      {console.log(this.state.category)}
      {console.log(this.state.final)}
      <AppBar position="static">
        <Toolbar>
          <IconButton
            edge="start"
            className={classes.menuButton}
            color="inherit"
            aria-label="open drawer"
          >
            <MenuIcon />
          </IconButton>
          <Typography className={classes.title} variant="h6" noWrap>
            A-Z Product Bidder
          </Typography>
          {/* <form sumbit="handlesubmit"> */}
          <FormControl className={classes.formControl}>
        <Select  displayEmpty className={classes.selectEmpty} onChange={this.handleChangeCategory}>
          <MenuItem value="All">All</MenuItem>
          <MenuItem value="Name">Name</MenuItem>
          <MenuItem value="Category">Category</MenuItem>
        </Select>
        </FormControl>
        {/* <FormControl className={classes.formControl}> */}

           <div className={classes.search}>
             <div className={classes.searchIcon}>
              <SearchIcon />
            </div>   
            <InputBase
              placeholder="Search…"
              classes={{
                root: classes.inputRoot,
                input: classes.inputInput,
              }} name="search"
              inputProps={{ 'aria-label': 'search' }}
              onChange={this.handleChangeSearch}

            />
          </div>
         
          <div className={classes.search}>
          

          <Button variant="contained" size="medium" color="primary" onClick={this.handleSubmit}  className={classes.margin} fullWidth>
                                     Search
        </Button>

            </div>
             {this.state.auth && (
            <div>
              <IconButton
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={this.handleMenu}
                color="inherit"
              >
                <AccountCircle />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={this.state.anchorEl}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                keepMounted
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                // open={open}
                onClose={this.handleClose}
              >
                <MenuItem onClick={this.handleClose}>Profile</MenuItem>
                <MenuItem onClick={this.handleClose}>My account</MenuItem>
              </Menu>
            </div>
          )}
    

  </Toolbar>
      </AppBar>
      
    </div>
  );}
}})

let pro=[
  {
    name:"nirmal",
    price:12321412
  }
]
//export default class Pass extends React.Component{
 // render(){
   // return <Fragment>
   //   {console.log("pass")}
  //  <SearchAppBar />
    {/* <Home p={pro} /> */}
    {/* <ProductCards product={pro}/> */}
 //   </Fragment>
//  }
//}