import React, { Component, Fragment } from "react"
import ProductCards from "./ProductCards"
import Pass from "./Pass"
import { fade, makeStyles, withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import InputBase from '@material-ui/core/InputBase';
import MenuIcon from '@material-ui/icons/Menu';
import SearchIcon from '@material-ui/icons/Search';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Menu from '@material-ui/core/Menu';
import Home from "./Home"


const useStyles = makeStyles(theme => ({
  formControl: {
    // margin: theme.spacing(1),
    width: 125,
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15)
  },
root: {
flexGrow: 1,
},
menuButton: {
marginRight: theme.spacing(2),
},
title: {
flexGrow: 1,
display: 'none',
[theme.breakpoints.up('sm')]: {
  display: 'block',
},
},
search: {
position: 'relative',
borderRadius: theme.shape.borderRadius,
backgroundColor: fade(theme.palette.common.white, 0.15),
'&:hover': {
  backgroundColor: fade(theme.palette.common.white, 0.25),
},
marginLeft: 0,
width: '100%',
[theme.breakpoints.up('sm')]: {
  marginLeft: theme.spacing(1),
  width: 'auto',
},
},
searchIcon: {
width: theme.spacing(7),
height: '100%',
position: 'absolute',
pointerEvents: 'none',
display: 'flex',
alignItems: 'center',
justifyContent: 'center',
},
inputRoot: {
color: 'inherit',
},
inputInput: {
padding: theme.spacing(1, 1, 1, 7),
transition: theme.transitions.create('width'),
width: '100%',
[theme.breakpoints.up('sm')]: {
  width: 120,
  '&:focus': {
    width: 200,
  },
},
},
selectEmpty: {
  marginTop: theme.spacing(2),
},
  paper: {
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
  rooot: {
    maxWidth: 200,
  },
  //formControl: {
    // margin: theme.spacing(1),
   // width: 125,
   // position: 'relative',
   // borderRadius: theme.shape.borderRadius,
  //  backgroundColor: fade(theme.palette.common.white, 0.15)
  //},
  root: {
    flexGrow: 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flexGrow: 1,
    display: 'none',
    [theme.breakpoints.up('md')]: {
      display: 'block',
    },
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: fade(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('md')]: {
      marginLeft: theme.spacing(1),
      width: 'auto',
    },
  },
  searchIcon: {
    width: theme.spacing(7),
    height: '100%',
    position: 'relative',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputRoot: {
    color: 'inherit',
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 7),
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
      width: 120,
      '&:focus': {
        width: 200,
      },
    },
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },

}));

let product = () => {
  return [
    {
      Name: "nirmal",
      price: 1000
    },
    {
      Name: "lion",
      price: 1000
    },
    {
      Name: "lion",
      price: 1000
    },
    {
      Name: "lion",
      price: 1000
    }, {
      Name: "lion",
      price: 1000
    },
  ]
}

export default withStyles(useStyles)(class extends Component {
  constructor(props) {
    super(props)
    this.state = {
      p: this.props.p,
      btn: this.props.btn,
      category:this.props.category,
      search:this.props.search,
      auth:true

    }
    console.log("constructor")
    console.log(props)
    console.log("p" + this.state.p)
  }
  handleChangeSearch = event => {
    // setSearch(event.target.value)
    console.log(event.target.value)
    this.setState({search:event.target.value})
  };
  handleChangeCategory = event => {
    // setCategory(event.target.value)
    console.log(event.target.value)
    this.setState({category:event.target.value})

  };
 


  render() {
    const {classes}=this.props
    console.log(this.state)

    return (
      <React.Fragment>
        {console.log("1")}

         <AppBar position="static">
        <Toolbar>
          <IconButton
            edge="start"
            className={classes.menuButton}
            color="inherit"
            aria-label="open drawer"
          >
            <MenuIcon />
          </IconButton>
          <Typography className={classes.title} variant="h6" noWrap>
            A-Z Product Bidder
          </Typography>
          {/* <div className={classes.search}> */}

          <FormControl className={classes.formControl}>
        <Select  displayEmpty className={classes.selectEmpty} onChange={this.handleChangeCategory}>
          <MenuItem value="All">All</MenuItem>
          <MenuItem value="Name">Name</MenuItem>
          <MenuItem value="Category">Category</MenuItem>
        </Select>
        </FormControl>
        {/* </div> */}
           <div className={classes.search}>
             {/* <div className={classes.searchIcon}> */}
              <SearchIcon />
            {/* </div>    */}
            <InputBase
              placeholder="Search…"
              classes={{
                root: classes.inputRoot,
                input: classes.inputInput,
              }} name="search"
              inputProps={{ 'aria-label': 'search' }}
              onChange={this.handleChangeSearch}
/>
          </div>
    {/* <div className={classes.search}>
          

          <Button variant="contained" size="medium" color="primary" onClick={this.handleSubmit}  className={classes.margin} fullWidth>
                                     Search
        </Button>

            </div> */}
             {this.state.auth && (
            <div>
              <IconButton
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={this.handleMenu}
                color="inherit"
              >
                <AccountCircle />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={this.state.anchorEl}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                keepMounted
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                // open={open}
                onClose={this.handleClose}
              >
                <MenuItem onClick={this.handleClose}>Profile</MenuItem>
                <MenuItem onClick={this.handleClose}>My account</MenuItem>
              </Menu>
            </div>
          )}
    

  </Toolbar>
      </AppBar>
 
        {/* <Pass /> */}
        <Grid container justify="center" style={{  padding: 20 }}>
          <Grid container item xs={12} spacing={5} md-offset={2}>
            {product().map(data => {
              if(data[this.state.category]===this.state.search)  // || this.state.category==="Name" || this.state.category==="Category"){
              {return (
                <React.Fragment>
                  <Grid item md={3} style={{ color: "black", textAlign: "center" }}>
                    <Card>
                      <CardActionArea>
                        <CardMedia
                          component="img"
                          alt="Contemplative Reptile"
                          height="300"
                          image="/static/images/cards/contemplative-reptile.jpg"
                          title="Contemplative Reptile"
                        />
                        <CardContent>
                          <Typography gutterBottom variant="h5" component="h2">
                            {data.Name}
                          </Typography>
                          <Typography variant="body2" color="textSecondary" component="p">
                            {data.price}
                          </Typography>
                        </CardContent>
                      </CardActionArea>
                      <Button variant="contained" size="medium" color="primary" className={classes.margin} fullWidth>
                        View Details
             </Button>
                      <Divider />
                      <Divider />
                      <Button variant="contained" size="medium" color="primary" className={classes.margin} fullWidth>
                        Buy Now
        </Button>
                    </Card>
                    {/* </Paper> */}
                  </Grid>

                </React.Fragment>
              )
            }})}
          </Grid>
        </Grid>

      </React.Fragment>
    )
  }

})