import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles(theme => ({
  paper: {
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
  root: {
    maxWidth: 345,
  },

}));
export default function NestedGrid(props) {
  const classes = useStyles();
  return (
    <div className="container-fluid" style={{padding:20}}>
      <Grid container justify="center" spacing={1}>
        <Grid container item xs={12} spacing={3}>
          {console.log(props)}
         {props.product.map(data=>{
               return (
                <React.Fragment>
                  <Grid item md={3} style={{color:"black",textAlign:"center"}}>
                  
                    <Card>
                <CardActionArea>
                  <CardMedia
                    component="img"
                    alt="Contemplative Reptile"
                    height="300"
                    image="/static/images/cards/contemplative-reptile.jpg"
                    title="Contemplative Reptile"
                  />
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="h2">
                      {data.name}
                    </Typography>
                    <Typography variant="body2" color="textSecondary" component="p">
                      {data.price}
                    </Typography>
                  </CardContent>
                </CardActionArea>
                <CardActions>
                <Button variant="contained" color="primary" className="btn-block">
                    Buy Now
                  </Button>
                  
                </CardActions>
              </Card>
        
                  </Grid>
                  
                </React.Fragment>
              )})}
           
        </Grid>
        
      </Grid>
    </div>
  );
}
