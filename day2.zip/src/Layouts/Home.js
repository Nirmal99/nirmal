import React,{Component,Fragment} from "react"
import ProductCard from "./ProductCards"
import SearchAppBar from "./SearchAppBar"
let product=()=>{ 
return [{
    name:"lion",
    price:1000
  },
  {
    name:"lion",
    price:1000
  },
  {
    name:"lion",
    price:1000
  },
  {
    name:"lion",
    price:1000
  },
  {
    name:"lion",
    price:1000
  }]
}
export default class Home extends Component
{
    constructor(){
        super()
        this.state={
            p:[]
        }
    }
    componentDidMount(props){
        let pro=product()
        console.log(pro)
        this.setState({p:pro})
    }
      render(){
          console.log(this.state.p)
        return <Fragment>
            <SearchAppBar />
            <ProductCard product={this.state.p} />
        </Fragment>
    }
}